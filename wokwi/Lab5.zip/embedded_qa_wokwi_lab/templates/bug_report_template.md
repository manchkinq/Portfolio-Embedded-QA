# Bug Report Template

## Title

## Environment
- Wokwi / real hardware:
- ESP32:
- Firmware:
- Date:

## Preconditions

## Steps to reproduce
1.
2.
3.

## Expected result

## Actual result

## Reproducibility
Always / Intermittent / Once

## Severity
Blocker / Critical / Major / Minor

## Evidence
- Serial log:
- Screenshot/video:
- Trace:
- Metrics:

## Notes / Hypothesis
Не видавайте припущення за підтверджену причину.
